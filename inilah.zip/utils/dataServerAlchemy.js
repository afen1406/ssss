const dataServerAlchemy = [
   //    {
   //       id: '81',
   //       name: 'JP Server',
   //       zoneId: '81',
   //    },
   //    {
   //       id: '82',
   //       name: 'KR Server',
   //       zoneId: '82',
   //    },
   {
      id: '83',
      name: 'SEA Server',
      zoneId: 83,
   },
   {
      id: '84',
      name: 'Global Server',
      zoneId: 84,
   },
   //    {
   //       id: '85',
   //       name: 'LATAM Server',
   //       zoneId: '85',
   //    },
];

module.exports = dataServerAlchemy;
