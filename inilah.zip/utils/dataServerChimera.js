let dataServerChimera = [
   {
      id: '1',
      name: 'DeathQuay',
      zoneId: '102',
   },
   {
      id: '1',
      name: 'CrosRiver',
      zoneId: '101',
   },
   {
      id: '1',
      name: 'Buckland',
      zoneId: '103',
   },
   {
      id: '1',
      name: 'BurntPlain',
      zoneId: '104',
   },
   {
      id: '1',
      name: 'JadeCoast',
      zoneId: '105',
   },
   {
      id: '1',
      name: 'PadHill',
      zoneId: '106',
   },
   {
      id: '1',
      name: 'RoniLand',
      zoneId: '107',
   },
   {
      id: '1',
      name: 'BeautyLake',
      zoneId: '108',
   },
   {
      id: '1',
      name: 'BlizzardBay',
      zoneId: '109',
   },
   {
      id: '1',
      name: 'LushField',
      zoneId: '110',
   },
   {
      id: '1',
      name: 'DustyPlain',
      zoneId: '111',
   },
   {
      id: '1',
      name: 'IceRiver',
      zoneId: '112',
   },
   {
      id: '1',
      name: 'GreenGully',
      zoneId: '113',
   },
   {
      id: '1',
      name: 'AzureField',
      zoneId: '114',
   },
   {
      id: '1',
      name: 'EosBeach',
      zoneId: '115',
   },
   {
      id: '1',
      name: 'TwilightBay',
      zoneId: '116',
   },
   {
      id: '1',
      name: 'Gray Plain',
      zoneId: '117',
   },
   {
      id: '1',
      name: 'SandSnow',
      zoneId: '118',
   },
   {
      id: '1',
      name: 'CragIslet',
      zoneId: '119',
   },
   {
      id: '1',
      name: 'SkyotHill',
      zoneId: '120',
   },
   {
      id: '1',
      name: 'GreenHill',
      zoneId: '121',
   },
];

module.exports = dataServerChimera;
